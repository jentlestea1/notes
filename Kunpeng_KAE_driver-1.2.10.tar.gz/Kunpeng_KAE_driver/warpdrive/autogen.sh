#!/bin/sh -x

autoreconf -i -f -v
